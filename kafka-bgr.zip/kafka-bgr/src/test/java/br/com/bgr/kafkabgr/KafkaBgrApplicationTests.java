package br.com.bgr.kafkabgr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaBgrApplicationTests {

	@Test
	void contextLoads() {
	}

}
