package br.com.bgr.kafkabgr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaBgrApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaBgrApplication.class, args);
	}

}
